from BTD6_Level_Control import get_insta_map_name, delay

while True:
    get_insta_map_name()
    delay(5001)